
import React from 'react';
import { StarIcon } from './IconComponents';

const Loader: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center text-center p-8">
      <div className="relative w-24 h-24">
        <StarIcon className="absolute inset-0 w-full h-full text-blue-300 animate-ping opacity-50" />
        <StarIcon className="absolute inset-0 w-full h-full text-blue-300 animate-pulse" />
      </div>
      <h2 className="text-3xl font-serif text-slate-800 mt-8">Creating Your StarSeed...</h2>
      <p className="text-slate-500 mt-2 max-w-sm">
        Our celestial AI is aligning the stars and weaving together future possibilities. This magical moment may take a minute.
      </p>
    </div>
  );
};

export default Loader;