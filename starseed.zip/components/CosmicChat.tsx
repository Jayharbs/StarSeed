
import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage } from '../types';
import { startChat, sendMessageToCeleste } from '../services/geminiService';
import { SendIcon, StarIcon } from './IconComponents';

const CosmicChat: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    startChat();
    setMessages([
      {
        id: 'init',
        sender: 'ai',
        text: "Hi! I'm Celeste, your personal AI astrologer. ✨ Ask me anything about your zodiac sign, compatibility, or what the stars have in store for you today! 🔮",
      },
    ]);
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: input.trim(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    const responseText = await sendMessageToCeleste(userMessage.text);

    const aiMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      sender: 'ai',
      text: responseText,
    };

    setMessages((prev) => [...prev, aiMessage]);
    setIsLoading(false);
  };

  return (
    <div className="w-full max-w-2xl h-[70vh] flex flex-col bg-white/60 rounded-2xl shadow-2xl border border-slate-200 backdrop-blur-sm animate-fade-in">
        <div className="p-4 border-b border-slate-200 text-center">
            <h2 className="text-2xl font-serif text-slate-800">Cosmic Chat</h2>
            <p className="text-sm text-slate-500">with Celeste, your AI Astrologer</p>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((msg) => (
                <div key={msg.id} className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                    {msg.sender === 'ai' && <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-300 to-pink-300 flex items-center justify-center flex-shrink-0"><StarIcon className="w-5 h-5 text-blue-100"/></div>}
                    <div className={`max-w-xs md:max-w-md p-3 rounded-2xl ${msg.sender === 'user' ? 'bg-blue-200 text-blue-900 rounded-br-none' : 'bg-slate-100 text-slate-700 rounded-bl-none'}`}>
                        <p className="text-sm break-words">{msg.text}</p>
                    </div>
                </div>
            ))}
            {isLoading && (
                <div className="flex items-end gap-2 justify-start">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-300 to-pink-300 flex items-center justify-center flex-shrink-0"><StarIcon className="w-5 h-5 text-blue-100 animate-pulse"/></div>
                    <div className="max-w-xs md:max-w-md p-3 rounded-2xl bg-slate-100 text-slate-700 rounded-bl-none">
                        <div className="flex items-center gap-1.5">
                            <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                            <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                            <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce"></span>
                        </div>
                    </div>
                </div>
            )}
            <div ref={chatEndRef} />
        </div>
        <form onSubmit={handleSend} className="p-4 border-t border-slate-200 flex items-center gap-2">
            <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about your horoscope..."
                disabled={isLoading}
                className="flex-grow bg-white border border-slate-300 rounded-md py-2 px-4 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400 transition"
                aria-label="Your message"
            />
            <button
                type="submit"
                disabled={isLoading || !input.trim()}
                className="inline-flex items-center justify-center w-10 h-10 border border-transparent rounded-full text-blue-800 bg-blue-200 hover:bg-blue-300 disabled:bg-blue-100 disabled:text-blue-300 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white focus:ring-blue-400 transition-colors flex-shrink-0"
                aria-label="Send message"
            >
                <SendIcon className="w-5 h-5" />
            </button>
        </form>
    </div>
  );
};

export default CosmicChat;