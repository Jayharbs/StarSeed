
import React, { useState } from 'react';
import { GeneratedResult, Celebrity, AgeCategory, GeneratedName } from '../types';
import { DownloadIcon, RedoIcon, SparklesIcon, CalendarIcon, CheckCircleIcon, XCircleIcon, ZodiacIcon, ShareIcon } from './IconComponents';

interface ResultDisplayProps {
  result: GeneratedResult;
  celebrity: Celebrity;
  onStartOver: () => void;
  onGenerateNewAge: (age: AgeCategory) => void;
}

const NameSuggestion: React.FC<{ name: GeneratedName }> = ({ name }) => (
    <div className="p-4 bg-white/70 rounded-lg border border-slate-200">
        <p className="font-bold text-lg text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-pink-500">{name.name}</p>
        <p className="text-slate-500 text-sm italic">"{name.meaning}"</p>
    </div>
);


const ResultDisplay: React.FC<ResultDisplayProps> = ({ result, celebrity, onStartOver, onGenerateNewAge }) => {
  const [activeAge, setActiveAge] = useState<AgeCategory>('infant');
  const [isSharing, setIsSharing] = useState(false);
  const isShareSupported = typeof navigator.share === 'function' && typeof navigator.canShare === 'function';

  const handleAgeClick = (age: AgeCategory) => {
      setActiveAge(age);
      onGenerateNewAge(age);
  }

  const handleShare = async () => {
    if (!isShareSupported) {
        alert("Sharing is not supported on your browser.");
        return;
    }
    
    setIsSharing(true);
    try {
        const response = await fetch(result.imageUrl);
        const blob = await response.blob();
        const file = new File([blob], `StarSeed_with_${celebrity.name.replace(/\s/g, '_')}.png`, { type: blob.type });

        const shareData = {
            title: 'My StarSeed Creation!',
            text: `Check out what my baby with ${celebrity.name} could look like! ✨ Created with the StarSeed app.`,
            files: [file],
        };

        if (navigator.canShare(shareData)) {
            await navigator.share(shareData);
        } else {
            // Fallback for browsers that might not support sharing files but support text/URL
            await navigator.share({
                title: shareData.title,
                text: shareData.text,
                url: window.location.href 
            });
        }
    } catch (error) {
        // Don't show an error if the user cancels the share dialog
        if ((error as Error).name !== 'AbortError') {
             console.error('Sharing failed:', error);
             alert('Oops! Something went wrong while trying to share.');
        }
    } finally {
        setIsSharing(false);
    }
  };

  return (
    <div className="w-full max-w-4xl animate-fade-in">
        <div className="text-center mb-6">
            <h2 className="text-4xl font-serif text-slate-800">Your StarSeed with {celebrity.name}</h2>
        </div>
      <div className="grid md:grid-cols-2 gap-8 items-start">
        <div className="flex flex-col items-center">
            <div className="relative w-full aspect-square bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden mb-4">
                <img src={result.imageUrl} alt="Generated baby" className="w-full h-full object-cover" />
                <div className="absolute top-2 right-2 bg-black/50 text-blue-200 text-xs px-2 py-1 rounded-full font-serif">
                    StarSeed&trade;
                </div>
            </div>
            
            <div className="w-full">
                <p className="text-center text-slate-500 mb-2 font-semibold">Age Preview</p>
                <div className="grid grid-cols-3 gap-2 bg-white/50 p-2 rounded-lg border border-slate-200">
                    {(['infant', 't toddler', 'teen'] as AgeCategory[]).map(age => (
                        <button key={age} onClick={() => handleAgeClick(age)} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400 ${activeAge === age ? 'bg-blue-200 text-blue-800' : 'bg-white hover:bg-slate-100 text-slate-600'}`}>
                            {age.charAt(0).toUpperCase() + age.slice(1)}
                        </button>
                    ))}
                </div>
            </div>
        </div>

        <div className="flex flex-col gap-6">
            <div>
                <h3 className="text-2xl font-serif flex items-center gap-2 mb-4 text-slate-800"><SparklesIcon className="w-6 h-6 text-pink-400"/> Name Suggestions</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {result.names.map((name, index) => <NameSuggestion key={index} name={name} />)}
                </div>
            </div>

            {result.profile && (
                <div className="p-6 bg-white/70 rounded-2xl border border-slate-200">
                    <h3 className="text-2xl font-serif flex items-center gap-2 mb-4"><CalendarIcon className="w-6 h-6 text-blue-400"/> Cosmic Profile</h3>
                    <div className="space-y-4">
                        <div>
                            <p className="font-bold text-slate-700">Predicted Arrival</p>
                            <p className="text-pink-500 italic">{result.profile.birthDate}</p>
                        </div>
                        {result.profile.sign && (
                            <div>
                                <p className="font-bold text-slate-700 flex items-center gap-1.5"><ZodiacIcon className="w-5 h-5 text-purple-500"/> {result.profile.sign.name}</p>
                                <p className="text-slate-600 pl-2 text-sm mt-1">{result.profile.sign.description}</p>
                            </div>
                        )}
                        <div>
                            <p className="font-bold text-slate-700 flex items-center gap-1.5"><CheckCircleIcon className="w-5 h-5 text-green-500"/> Superpowers</p>
                            <ul className="list-none space-y-1 mt-1">
                                {result.profile.strengths.map((strength, i) => (
                                    <li key={i} className="text-slate-600 pl-2">{strength}</li>
                                ))}
                            </ul>
                        </div>
                         <div>
                            <p className="font-bold text-slate-700 flex items-center gap-1.5"><XCircleIcon className="w-5 h-5 text-red-500"/> Quirky Challenges</p>
                            <ul className="list-none space-y-1 mt-1">
                                {result.profile.weaknesses.map((weakness, i) => (
                                    <li key={i} className="text-slate-600 pl-2">{weakness}</li>
                                ))}
                            </ul>
                        </div>
                    </div>
                </div>
            )}

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-4">
                <a 
                    href={result.imageUrl} 
                    download={`StarSeed_with_${celebrity.name.replace(/\s/g, '_')}.png`}
                    className="col-span-1 inline-flex items-center justify-center gap-2 px-6 py-3 border border-transparent text-base font-semibold rounded-md text-pink-800 bg-pink-200 hover:bg-pink-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-pink-50 focus:ring-pink-500 transition-colors"
                >
                    <DownloadIcon className="w-5 h-5"/>
                    Save Image
                </a>
                
                {isShareSupported && (
                    <button
                        onClick={handleShare}
                        disabled={isSharing}
                        className="col-span-1 inline-flex items-center justify-center gap-2 px-6 py-3 border border-transparent text-base font-semibold rounded-md text-blue-800 bg-blue-200 hover:bg-blue-300 disabled:bg-blue-100 disabled:text-blue-300 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-pink-50 focus:ring-blue-500 transition-colors"
                    >
                        <ShareIcon className="w-5 h-5"/>
                        {isSharing ? 'Sharing...' : 'Share'}
                    </button>
                )}

                <button
                    onClick={onStartOver}
                    className="col-span-2 sm:col-span-1 inline-flex items-center justify-center gap-2 px-6 py-3 border border-slate-300 text-base font-medium rounded-md text-slate-600 bg-white hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-pink-50 focus:ring-blue-400 transition-colors"
                >
                    <RedoIcon className="w-5 h-5"/>
                    Start Over
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ResultDisplay;