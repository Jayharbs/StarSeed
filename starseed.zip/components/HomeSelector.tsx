import React from 'react';
import { SparklesIcon, ChatBubbleIcon } from './IconComponents';

interface HomeSelectorProps {
  onSelectGenerator: () => void;
  onSelectChat: () => void;
}

const ChoiceCard: React.FC<{ icon: React.ReactNode; title: string; description: string; onClick: () => void; }> = ({ icon, title, description, onClick }) => (
    <button 
        onClick={onClick}
        className="group w-full max-w-sm p-8 bg-white/60 rounded-2xl shadow-lg border border-slate-200 backdrop-blur-sm text-center transition-all duration-300 hover:shadow-2xl hover:border-blue-300 hover:-translate-y-2"
    >
        <div className="w-20 h-20 bg-gradient-to-br from-blue-400 to-pink-400 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg transition-transform duration-300 group-hover:scale-110">
            {icon}
        </div>
        <h2 className="text-3xl font-serif text-slate-800 mb-2">{title}</h2>
        <p className="text-slate-500">{description}</p>
    </button>
);


const HomeSelector: React.FC<HomeSelectorProps> = ({ onSelectGenerator, onSelectChat }) => {
  return (
    <div className="flex flex-col md:flex-row items-center justify-center gap-8 md:gap-12 animate-fade-in">
      <ChoiceCard
        icon={<SparklesIcon className="w-10 h-10 text-blue-200" />}
        title="Create a StarSeed"
        description="Upload your photo and choose a star to see your AI-generated baby."
        onClick={onSelectGenerator}
      />
      <ChoiceCard
        icon={<ChatBubbleIcon className="w-10 h-10 text-blue-200" />}
        title="Cosmic Chat"
        description="Chat with our AI Astrologer for fun insights and daily horoscopes."
        onClick={onSelectChat}
      />
    </div>
  );
};

export default HomeSelector;