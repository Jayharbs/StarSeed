import React from 'react';
import { StarIcon, HomeIcon } from './IconComponents';

interface HeaderProps {
  showHomeButton: boolean;
  onGoHome: () => void;
}

const Header: React.FC<HeaderProps> = ({ showHomeButton, onGoHome }) => {
  return (
    <header className="text-center w-full relative">
      {showHomeButton && (
        <button 
          onClick={onGoHome}
          className="absolute top-1/2 -translate-y-1/2 left-0 sm:left-4 md:left-8 flex items-center gap-2 text-slate-500 hover:text-blue-500 transition-colors p-2 rounded-lg"
          aria-label="Go to Home Screen"
        >
          <HomeIcon className="w-6 h-6" />
          <span className="hidden sm:inline font-semibold">Home</span>
        </button>
      )}
      <div className="flex items-center justify-center gap-4">
        <StarIcon className="w-10 h-10 text-blue-300" />
        <h1 className="text-5xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-pink-400">
          StarSeed
        </h1>
        <StarIcon className="w-10 h-10 text-pink-300" />
      </div>
      <p className="mt-3 text-lg text-slate-500">
        See the star-powered future you could create.
      </p>
    </header>
  );
};

export default Header;