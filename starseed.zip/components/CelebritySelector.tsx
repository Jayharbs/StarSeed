
import React, { useState } from 'react';
import { Celebrity } from '../types';
import { SearchIcon } from './IconComponents';

interface CelebritySelectorProps {
  onCelebritySelect: (celebrity: Celebrity) => void;
  userImageUrl?: string;
}

const CelebritySelector: React.FC<CelebritySelectorProps> = ({ onCelebritySelect, userImageUrl }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<string[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!searchQuery.trim()) {
        setError("Please enter a name to search.");
        return;
    }
    setIsSearching(true);
    setSearchResults([]);

    try {
        const searchName = encodeURIComponent(searchQuery.trim());
        let finalImageUrls: string[] = [];
        let primaryImageTitle: string | null = null;

        // Step 1: Get the primary page image from Wikipedia (often the most recent/official portrait)
        const primaryImageResponse = await fetch(`https://en.wikipedia.org/w/api.php?action=query&prop=pageimages&titles=${searchName}&pithumbsize=400&format=json&origin=*`);
        const primaryImageData = await primaryImageResponse.json();
        const primaryImagePages = primaryImageData.query.pages;
        const pageId = Object.keys(primaryImagePages)[0];

        if (pageId === '-1') {
            // Do nothing, we can still search commons
        } else {
             const primaryPage = primaryImagePages[pageId];
            if (primaryPage.thumbnail && primaryPage.thumbnail.source) {
                finalImageUrls.push(primaryPage.thumbnail.source);
                primaryImageTitle = primaryPage.pageimage;
            }
        }
        
        // Step 2: Search Wikimedia Commons directly for a larger pool of images
        const commonsSearchResponse = await fetch(`https://commons.wikimedia.org/w/api.php?action=query&list=search&srsearch=${searchName}&srnamespace=6&srlimit=50&format=json&origin=*`);
        if (!commonsSearchResponse.ok) throw new Error('Network error when searching Wikimedia Commons.');
        const commonsSearchData = await commonsSearchResponse.json();

        if (commonsSearchData.query.search.length > 0) {
            // Step 3: Filter titles for relevance
            let imageTitles = commonsSearchData.query.search
                .map((result: { title: string }) => result.title)
                .filter((title: string) => 
                    title !== primaryImageTitle &&
                    /\.(jpg|jpeg|png)$/i.test(title) &&
                    !/logo|signature|emblem|flag|coat of arms|map/i.test(title)
                );

            // Fetch URLs for the top 20 relevant titles to ensure we get enough valid images
            const titlesToFetch = imageTitles.slice(0, 20); 

            if (titlesToFetch.length > 0) {
                // Step 4: Get actual image URLs from Commons
                const titlesParam = encodeURIComponent(titlesToFetch.join('|'));
                const imageUrlsResponse = await fetch(`https://commons.wikimedia.org/w/api.php?action=query&titles=${titlesParam}&prop=imageinfo&iiprop=url&iiurlwidth=400&format=json&origin=*`);
                if (!imageUrlsResponse.ok) throw new Error('Network error when fetching image URLs from Commons.');

                const imageUrlsData = await imageUrlsResponse.json();
                if (imageUrlsData.query && imageUrlsData.query.pages) {
                    const imageUrlsPages = imageUrlsData.query.pages;
                    const otherUrls = Object.values(imageUrlsPages)
                        .map((page: any) => page.imageinfo?.[0]?.thumburl)
                        .filter(Boolean);

                    finalImageUrls.push(...(otherUrls as string[]));
                }
            }
        }

        if (finalImageUrls.length === 0) {
            throw new Error(`No suitable images could be loaded for "${searchQuery}". Please check the spelling or try another name.`);
        }
        
        // Use a Set to easily deduplicate URLs before slicing
        const uniqueUrls = [...new Set(finalImageUrls)];

        setSearchResults(uniqueUrls.slice(0, 16));

    } catch (err: any) {
        setError(err.message || 'An unexpected error occurred. Please try again.');
        setSearchResults([]);
    } finally {
        setIsSearching(false);
    }
  };

  const handleSelectImage = (imageUrl: string) => {
    const capitalizedName = searchQuery.trim().split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    const selectedCelebrity: Celebrity = {
        id: Date.now(),
        name: capitalizedName,
        description: 'Public Figure',
        imageUrl: imageUrl,
    };
    onCelebritySelect(selectedCelebrity);
  };

  return (
    <div className="w-full">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-serif text-slate-800 mb-2">Step 2: Find a Star</h2>
        <p className="text-slate-500">Search for any public figure to be your co-creator.</p>
      </div>

      <div className="flex justify-center items-center gap-8 mb-10">
        {userImageUrl && (
          <div className="text-center">
            <img src={userImageUrl} alt="You" className="w-32 h-32 object-cover rounded-full border-4 border-blue-400 shadow-lg"/>
            <p className="mt-2 font-semibold text-lg">You</p>
          </div>
        )}
        <div className="text-5xl font-serif text-pink-400">+</div>
        <div className="text-center">
          <div className="w-32 h-32 rounded-full border-4 border-dashed border-slate-300 flex items-center justify-center bg-slate-100/50">
            <span className="text-slate-400 text-5xl">?</span>
          </div>
          <p className="mt-2 font-semibold text-lg">A Star</p>
        </div>
      </div>

      <form onSubmit={handleSearch} className="max-w-xl mx-auto mb-8 flex gap-2">
        <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="e.g., 'Audrey Hepburn' or 'Chris Hemsworth'"
            className="flex-grow bg-white border border-slate-300 rounded-md py-3 px-4 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400 transition"
            aria-label="Search for a celebrity"
        />
        <button
            type="submit"
            disabled={isSearching}
            className="inline-flex items-center justify-center gap-2 px-6 py-3 border border-transparent text-base font-semibold rounded-md text-blue-800 bg-blue-200 hover:bg-blue-300 disabled:bg-blue-100 disabled:text-blue-300 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-pink-50 focus:ring-blue-400 transition-colors"
        >
            <SearchIcon className="w-5 h-5" />
            <span>{isSearching ? 'Searching...' : 'Search'}</span>
        </button>
      </form>
      
      {error && <p className="text-center text-red-600 mb-4" role="alert">{error}</p>}

      {isSearching && (
          <div className="text-center text-slate-500" aria-live="polite">Searching Wikimedia Commons for photos...</div>
      )}

      {searchResults.length > 0 && (
        <>
            <p className="text-center text-slate-600 mb-4">Select the best photo to inspire your StarSeed.</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-4">
                {searchResults.map((url, index) => (
                <button
                    key={index}
                    onClick={() => handleSelectImage(url)}
                    className="group relative aspect-[2/3] rounded-lg overflow-hidden focus:outline-none focus:ring-4 focus:ring-blue-400 focus:ring-opacity-75"
                    aria-label={`Select image ${index + 1} for ${searchQuery}`}
                >
                    <img
                        src={url}
                        alt={`Search result for ${searchQuery} ${index + 1}`}
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent"></div>
                    <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-70 transition-opacity duration-300 flex items-center justify-center">
                        <span className="text-blue-800 font-bold text-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300">Select</span>
                    </div>
                </button>
                ))}
            </div>
        </>
      )}
    </div>
  );
};

export default CelebritySelector;
