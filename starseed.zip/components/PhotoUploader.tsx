
import React, { useState, useCallback } from 'react';
import { UploadIcon } from './IconComponents';

interface PhotoUploaderProps {
  onPhotoUpload: (base64: string, mimeType: string, url: string) => void;
}

const PhotoUploader: React.FC<PhotoUploaderProps> = ({ onPhotoUpload }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleFile = useCallback((file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const url = e.target?.result as string;
        const base64 = url.split(',')[1];
        onPhotoUpload(base64, file.type, url);
      };
      reader.readAsDataURL(file);
    }
  }, [onPhotoUpload]);

  const handleDragOver = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  }, [handleFile]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  return (
    <div className="w-full max-w-md p-8 bg-white/60 rounded-2xl shadow-2xl border border-slate-200 backdrop-blur-sm text-center">
      <h2 className="text-3xl font-serif text-slate-800 mb-2">Step 1: Your Photo</h2>
      <p className="text-slate-500 mb-6">Upload a clear, front-facing selfie.</p>
      
      <label
        htmlFor="photo-upload"
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`relative block w-full border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-all duration-300 ${
          isDragging ? 'border-blue-300 bg-blue-100/50' : 'border-slate-300 hover:border-blue-400'
        }`}
      >
        <UploadIcon className="mx-auto h-12 w-12 text-slate-400 mb-4" />
        <span className="block font-semibold text-slate-600">
          Drop your image here or click to browse
        </span>
        <span className="mt-1 block text-sm text-slate-500">
          PNG, JPG, GIF up to 10MB
        </span>
        <input
          id="photo-upload"
          name="photo-upload"
          type="file"
          className="sr-only"
          accept="image/*"
          onChange={handleChange}
        />
      </label>
    </div>
  );
};

export default PhotoUploader;