// FIX: Implementing the main StarseedGenerator component to manage application state and flow.
import React, { useState, useCallback } from 'react';
import { Celebrity, GeneratedResult, AgeCategory, UserPhoto } from '../types';
// FIX: Import generateStarseed to combine image and profile generation.
import { generateStarseed, generateStarseedImage } from '../services/geminiService';
import PhotoUploader from './PhotoUploader';
import CelebritySelector from './CelebritySelector';
import ResultDisplay from './ResultDisplay';
import Loader from './Loader';

type AppState = 'upload' | 'select' | 'loading' | 'result';

const StarseedGenerator: React.FC = () => {
  const [step, setStep] = useState<AppState>('upload');
  const [userPhoto, setUserPhoto] = useState<UserPhoto | null>(null);
  const [selectedCelebrity, setSelectedCelebrity] = useState<Celebrity | null>(null);
  const [generatedResult, setGeneratedResult] = useState<GeneratedResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handlePhotoUpload = useCallback((base64: string, mimeType: string, url: string) => {
    setUserPhoto({ base64, mimeType, url });
    setStep('select');
  }, []);

  const handleCelebritySelect = useCallback(async (celebrity: Celebrity) => {
    if (!userPhoto) {
      setError('User photo is missing.');
      return;
    }
    setSelectedCelebrity(celebrity);
    setStep('loading');
    setError(null);
    try {
      const result = await generateStarseed(userPhoto, celebrity, 'infant');
      setGeneratedResult(result);
      setStep('result');
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An error occurred while generating your StarSeed.');
      setStep('select');
    }
  }, [userPhoto]);
  
  const handleGenerateNewAge = useCallback(async (age: AgeCategory) => {
    if (!userPhoto || !selectedCelebrity) {
        setError('Missing data to generate a new age.');
        return;
    }
    setStep('loading');
    setError(null);
     try {
      const imageUrl = await generateStarseedImage(userPhoto, selectedCelebrity, age);
      setGeneratedResult(prevResult => ({
          ...prevResult!,
          imageUrl: imageUrl,
      }));
    } catch (err: any) {
      console.error(err);
      setError(err.message || `Failed to generate ${age} image.`);
    } finally {
      setStep('result');
    }
  }, [userPhoto, selectedCelebrity]);


  const handleStartOver = useCallback(() => {
    setStep('upload');
    setUserPhoto(null);
    setSelectedCelebrity(null);
    setGeneratedResult(null);
    setError(null);
  }, []);

  const renderStep = () => {
    if (step !== 'loading' && error) {
       return <div className="text-center p-8 bg-red-100 border border-red-400 text-red-700 rounded-lg max-w-md mx-auto">
           <h3 className="text-xl font-bold mb-2">Oops! Something went wrong.</h3>
           <p>{error}</p>
           <button onClick={handleStartOver} className="mt-4 px-4 py-2 bg-red-200 text-red-800 rounded hover:bg-red-300 font-semibold transition-colors">Try Again</button>
       </div>
    }
      
    switch (step) {
      case 'upload':
        return <PhotoUploader onPhotoUpload={handlePhotoUpload} />;
      case 'select':
        return <CelebritySelector onCelebritySelect={handleCelebritySelect} userImageUrl={userPhoto?.url} />;
      case 'loading':
        return <Loader />;
      case 'result':
        if (generatedResult && selectedCelebrity) {
          return <ResultDisplay result={generatedResult} celebrity={selectedCelebrity} onStartOver={handleStartOver} onGenerateNewAge={handleGenerateNewAge} />;
        }
        // Fallback to start over if result is missing
        handleStartOver();
        return null;
      default:
        return null;
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto p-4 md:p-8 flex justify-center">
      {renderStep()}
    </div>
  );
};

export default StarseedGenerator;