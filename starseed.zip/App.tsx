// FIX: Populating the empty App.tsx file with the main application component.
import React, { useState } from 'react';
import Header from './components/Header';
import StarseedGenerator from './components/StarseedGenerator';
import HomeSelector from './components/HomeSelector';
import CosmicChat from './components/CosmicChat';

type AppView = 'home' | 'generator' | 'chat';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('home');

  const handleGoHome = () => setView('home');

  const renderView = () => {
    switch(view) {
      case 'generator':
        return <StarseedGenerator />;
      case 'chat':
        return <CosmicChat />;
      case 'home':
      default:
        return <HomeSelector 
          onSelectGenerator={() => setView('generator')}
          onSelectChat={() => setView('chat')}
        />;
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-blue-50 to-white flex flex-col items-center justify-start p-4 sm:p-6 md:p-8 font-sans">
        <Header showHomeButton={view !== 'home'} onGoHome={handleGoHome} />
        <main className="w-full flex-grow flex items-center justify-center mt-8 sm:mt-12">
            {renderView()}
        </main>
        <footer className="w-full text-center p-4 mt-auto">
            <p className="text-sm text-slate-400">
                Powered by Google Gemini. For entertainment purposes only.
            </p>
        </footer>
    </div>
  );
};

export default App;