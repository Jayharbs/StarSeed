
import { Celebrity } from '../types';

export const celebrities: Celebrity[] = [
  { id: 1, name: 'Aria Vance', description: 'Pop Icon', imageUrl: 'https://picsum.photos/seed/aria/400/600' },
  { id: 2, name: 'Leo Rivera', description: 'Action Hero', imageUrl: 'https://picsum.photos/seed/leo/400/600' },
  { id: 3, name: 'Chloe Kim', description: 'Rom-Com Queen', imageUrl: 'https://picsum.photos/seed/chloe/400/600' },
  { id: 4, name: 'Jax Orion', description: 'Rock Legend', imageUrl: 'https://picsum.photos/seed/jax/400/600' },
  { id: 5, name: 'Isla Zhang', description: 'Sci-Fi Star', imageUrl: 'https://picsum.photos/seed/isla/400/600' },
  { id: 6, name: 'Ethan Hawke', description: 'Indie Darling', imageUrl: 'https://picsum.photos/seed/ethan/400/600' },
  { id: 7, name: 'Maya Singh', description: 'Supermodel', imageUrl: 'https://picsum.photos/seed/maya/400/600' },
  { id: 8, name: 'Finn Wolfhard', description: 'Breakout Talent', imageUrl: 'https://picsum.photos/seed/finn/400/600' },
  { id: 9, name: 'Zendaya', description: 'Global Superstar', imageUrl: 'https://picsum.photos/seed/zendaya/400/600' },
  { id: 10, name: 'Ken Watanabe', description: 'Esteemed Actor', imageUrl: 'https://picsum.photos/seed/ken/400/600' },
  { id: 11, name: 'Sofia Elara', description: 'Opera Diva', imageUrl: 'https://picsum.photos/seed/sofia/400/600' },
  { id: 12, name: 'Kai Sterling', description: 'Olympic Champion', imageUrl: 'https://picsum.photos/seed/kai/400/600' },
];
