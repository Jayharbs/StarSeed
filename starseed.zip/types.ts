// FIX: Populating the empty types.ts file with necessary type definitions.
export interface Celebrity {
  id: number;
  name: string;
  description: string;
  imageUrl: string;
}

export interface UserPhoto {
  base64: string;
  mimeType: string;
  url: string;
}

export type AgeCategory = 'infant' | 'toddler' | 'teen';

export interface GeneratedName {
  name: string;
  meaning: string;
}

export interface CosmicProfile {
  birthDate: string;
  sign: {
    name: string;
    description: string;
  };
  strengths: string[];
  weaknesses: string[];
}

export interface GeneratedResult {
  imageUrl: string;
  names: GeneratedName[];
  profile: CosmicProfile;
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  isLoading?: boolean;
}