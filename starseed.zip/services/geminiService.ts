// FIX: Implementing the Gemini service to handle AI generation tasks.
import { GoogleGenAI, Modality, Type, Chat } from '@google/genai';
import { AgeCategory, GeneratedResult, UserPhoto } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

async function urlToGenerativePart(url: string) {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Failed to fetch image from ${url}: ${response.statusText}`);
    }
    const blob = await response.blob();
    
    return new Promise<{inlineData: {data: string, mimeType: string}}>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64Data = (reader.result as string)?.split(',')[1];
            if (base64Data) {
                resolve({
                    inlineData: {
                        data: base64Data,
                        mimeType: blob.type,
                    },
                });
            } else {
                reject(new Error("Failed to convert image to base64."));
            }
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
}

const profileSchema = {
    type: Type.OBJECT,
    properties: {
        names: {
            type: Type.ARRAY,
            description: "Three creative and fitting name suggestions for the child. One boy name, one girl name, one gender-neutral name.",
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING, description: "The suggested name." },
                    meaning: { type: Type.STRING, description: "A brief, poetic meaning of the name." },
                },
                required: ['name', 'meaning'],
            },
        },
        profile: {
            type: Type.OBJECT,
            properties: {
                birthDate: {
                    type: Type.STRING,
                    description: "A fun, predicted birthday for the child within the next two years, e.g., 'October 26, 2025'."
                },
                sign: {
                    type: Type.OBJECT,
                    properties: {
                        name: { type: Type.STRING, description: "The child's zodiac sign based on the birth date." },
                        description: { type: Type.STRING, description: "A one-sentence, imaginative, teen-friendly description of the zodiac sign's personality, connecting it to the celebrity parent and the generated image." },
                    },
                    required: ['name', 'description'],
                },
                strengths: {
                    type: Type.ARRAY,
                    description: "A list of three unique and positive personality traits or 'superpowers' the child might have, written in a fun, teen-friendly tone.",
                    items: { type: Type.STRING },
                },
                weaknesses: {
                    type: Type.ARRAY,
                    description: "A list of two quirky, lighthearted challenges or weaknesses the child might face, written in a fun, teen-friendly tone.",
                    items: { type: Type.STRING },
                },
            },
            required: ['birthDate', 'sign', 'strengths', 'weaknesses'],
        }
    },
    required: ['names', 'profile'],
};

export const generateStarseedImage = async (
    userPhoto: UserPhoto,
    celebrity: { name: string; imageUrl: string },
    age: AgeCategory
): Promise<string> => {
    const userImagePart = {
        inlineData: {
            data: userPhoto.base64,
            mimeType: userPhoto.mimeType,
        },
    };
    
    const celebrityImagePart = await urlToGenerativePart(celebrity.imageUrl);

    const imagePrompt = `These are two individuals. The first image is a user's selfie, and the second is the celebrity ${celebrity.name}. Act as a sensitive portrait artist. Your task is to generate a photorealistic image of a hypothetical child they might have together, depicted as a ${age}.
    
    CRITICAL INSTRUCTIONS:
    1.  **Accurate Feature Blending:** Faithfully blend the features of both individuals. Create a believable and natural mix of their skin tones. If the parents are of different races, the child MUST look mixed-race.
    2.  **Inherit Traits:** Combine hair texture, eye shape, nose, and mouth from both parents to produce a unique-looking child.
    3.  **High Quality:** The final image must be a high-quality, tasteful, portrait-style photograph.`;

    const imageResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
            parts: [
                { text: imagePrompt },
                userImagePart,
                celebrityImagePart,
            ],
        },
        config: {
            responseModalities: [Modality.IMAGE],
        },
    });

    const imagePart = imageResponse.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
    if (!imagePart || !imagePart.inlineData) {
        throw new Error('Image generation failed.');
    }
    return `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`;
};

export const generateStarseedProfile = async (
    celebrityName: string
): Promise<Omit<GeneratedResult, 'imageUrl'>> => {
    const profilePrompt = `You are a whimsical, teen-friendly astrologer. Based on the public persona of the celebrity ${celebrityName} and a user, create a "Cosmic Profile" for their hypothetical child. The tone should be fun, positive, and easy for a teenager to understand. Connect the zodiac sign's traits to the celebrity's known characteristics.`;

    const profileResponse = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: profilePrompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: profileSchema,
        },
    });

    try {
        return JSON.parse(profileResponse.text);
    } catch(e) {
        console.error("Failed to parse profile JSON:", profileResponse.text);
        throw new Error("The AI returned an invalid profile format. Please try again.");
    }
};

// FIX: Add missing generateStarseed function to orchestrate image and profile generation.
export const generateStarseed = async (
    userPhoto: UserPhoto,
    celebrity: { name: string; imageUrl: string },
    age: AgeCategory
): Promise<GeneratedResult> => {
    const [imageUrl, profileData] = await Promise.all([
        generateStarseedImage(userPhoto, celebrity, age),
        generateStarseedProfile(celebrity.name),
    ]);

    return {
        imageUrl,
        ...profileData,
    };
};

// --- CHAT SERVICE ---

let chatSession: Chat | null = null;

const CELESTE_PERSONA = "You are Celeste, a friendly and modern AI astrologer. Your tone is upbeat, encouraging, and easy for a teenager to understand. You love using emojis ✨🔮🌙. You provide fun, insightful, and positive astrological guidance. Never give medical, legal, or financial advice. Keep your answers concise and conversational.";

export const startChat = () => {
  chatSession = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: CELESTE_PERSONA,
    },
  });
};

export const sendMessageToCeleste = async (message: string): Promise<string> => {
  if (!chatSession) {
    startChat();
  }
  try {
    const response = await chatSession!.sendMessage({ message });
    return response.text;
  } catch (error) {
    console.error("Error sending message to Gemini:", error);
    return "Oops! I'm having a little trouble connecting to the cosmos right now. Please try again in a moment.";
  }
};